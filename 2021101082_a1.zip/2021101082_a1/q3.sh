#!/bin/bash

input_file="input.txt";

#part a
size="$(wc -c < $input_file)";
echo "$size";

#part b
echo "-------------------------------";
no_of_lines="$(wc -l < $input_file)";
echo "$no_of_lines";

#part c
echo "-------------------------------";
no_of_words="$(wc -w < $input_file)";
echo "$no_of_words";

#part d
echo "-------------------------------";
count_line=1;
while IFS= read -r line 
do 
    if [ $count_line -eq 1 ]
    then
    {
        no_of_words_line="$(cat $input_file|head -n 1|wc -w)";
    }

    else
    {
        no_of_words_line="$(cat $input_file|head -n $count_line|tail -n 1|wc -w)";
    }

    fi;

    echo "Line number $count_line: - Count of words: $no_of_words_line";

    let count_line++;
done < $input_file;

#part e
echo "-------------------------------";
egrep -o "\b[[:alpha:]]+\b" $input_file | \

awk '{ count[$0]++ }
END {
for(ind in count)
{ 
    if ( count[ind] != 1 )
    {
        printf("Word: %-14s - Repetition of word: %d\n",ind,count[ind]); }
    }  
}'