#!/bin/bash

#q5a
read -a string;
rev_string="$(echo $string|rev)";
echo "$rev_string";

#q5b
read -a string;
rev_string="$(echo $string|rev)";
new_string="$(echo "$rev_string" | tr '[A-Z]' '[B-ZA-A]'| tr '[a-z]' '[b-za-a]')";
echo "$new_string";

#q5c
read -a string;
let length=(${#string}/2);
half_string=${string:0:length};
half_rev="$(echo $half_string|rev)";
second_string=${string:length:$((${#string}-1))};
new_string1="${half_rev}${second_string}";
echo "$new_string1";
