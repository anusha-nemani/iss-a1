#!/bin/bash

input_file="array.csv";

arr_csv=() 
while IFS= read -r line 
do
    arr_csv+=("$line")
done < $input_file

arr=(${arr_csv//,/ });

#for finding the number of elements in the array
length=${#arr[*]};

for ((i=0;i<$length;i++))
{
    for ((j=0;j<$length-1;j++))
    {
        if [ ${arr[j]} -gt ${arr[j+1]} ]
        then
        {
            temp=${arr[j]};
            arr[j]=${arr[j+1]};
            arr[j+1]=$temp;
        }

        fi;
    }
}

echo ${arr[@]};