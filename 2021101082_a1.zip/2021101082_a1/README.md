# DSA ASSIGNMENT 1
## Sections

- [Platform](#platform)

- [Git repository link](#Git-repository-link)

- [Q1](#Q1)

- [Q3](#Q3)

- [Q4](#Q4)

---
## Platform

Code is compiled, run and tested according on 

UBUNTU 20.04

---

## Git repository link

https://github.com/anusha-nemani/iss-a1

---

## Q1

Input for the commands is taken from *quotes.txt*. The output of the commands is printed on the terminal, as well as saved in another file *input.txt*. This file, *input.txt*, is used as an input file in the other questions.

### NOTE: The changes are not reflected in the original file.

---

## Q3

Input file used for this question is *input.txt*, which was created in Q1.

---

## Q4

Input for this question is taken from a *csv* file and then sorted.

---

