#!/bin/bash

input_file="quotes.txt";

awk '!seen[$0]++' $input_file| sed '/^$/d'| awk -F '~' '{print $2 " once said " "\x22"$1"\x22" > "speech.txt"}';

