#!/bin/bash

input_file="quotes.txt";

#q1a
sed '/^$/d' $input_file # '/^$/d' is used to specify that blank lines need to be deleted. 
                          # this command doesn't modify the file, but just prints the required output in the terminal.


#q1b
echo "----------------------------------------------------------------------------------------";
echo "----------------------------------------------------------------------------------------";
awk '!seen[$0]++' $input_file| sed '/^$/d';

awk '!seen[$0]++' $input_file| sed '/^$/d'  > input.txt ;

